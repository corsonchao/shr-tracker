/**
 * Superhot Rock Tracker — AI proxy as a Cloudflare Worker.
 * Use this if the Supabase CLI is a hassle. No CLI, no Docker, no install:
 * everything below is pasted into Cloudflare's browser editor.
 *
 * SETUP (about 5 minutes)
 *  1. Sign up free at https://dash.cloudflare.com  → Workers & Pages
 *  2. Create → Workers → "Hello World" starter → Deploy
 *  3. Click "Edit code", delete the sample, paste this whole file, Deploy
 *  4. Back on the Worker page: Settings → Variables and Secrets →
 *     Add a SECRET named ANTHROPIC_API_KEY with your sk-ant-… value → Save
 *  5. Copy the Worker URL (https://<name>.<subdomain>.workers.dev) into
 *     AI_ENDPOINT in config.js
 *
 * OPTIONAL: replace "*" in ALLOW_ORIGIN with your GitHub Pages URL, e.g.
 * "https://your-org.github.io", so only your site can call it.
 */

const ALLOW_ORIGIN = "*";
const MODEL = "claude-sonnet-4-6"; // "claude-haiku-4-5" is ~3x cheaper

const CORS = {
  "Access-Control-Allow-Origin": ALLOW_ORIGIN,
  "Access-Control-Allow-Headers": "content-type, authorization, apikey",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response("ok", { headers: CORS });
    if (request.method !== "POST")
      return json({ error: "Send a POST request." }, 405);

    try {
      const { milestone, workstreamName, memberName, existingTasks, knowledge, weekOf } =
        await request.json();

      const system =
        "You are the planning assistant for the Bezos Earth Fund Superhot Rock team. " +
        "You break upcoming milestones into concrete weekly tasks, grounded in the team's " +
        "knowledge base and consistent with tasks already tracked in other workstreams. " +
        "Respond ONLY with a JSON array, no prose, no markdown fences. Each element: " +
        '{"title": string, "priority": "high"|"medium"|"low", "deadline": "YYYY-MM-DD", "rationale": string}. ' +
        "3-7 tasks. Deadlines must be realistic relative to the milestone and the week given.";

      const user = [
        `Week of: ${weekOf}`,
        `Workstream: ${workstreamName}`,
        `Team member: ${memberName}`,
        `Upcoming milestone: ${milestone}`,
        "",
        "=== Relevant knowledge base excerpts (SHR bible) ===",
        knowledge || "(none provided)",
        "",
        "=== Existing tasks across workstreams (avoid duplicates; learn from patterns) ===",
        existingTasks || "(none)",
      ].join("\n");

      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 1200,
          system,
          messages: [{ role: "user", content: user }],
        }),
      });

      const data = await resp.json();
      if (!resp.ok) return json({ error: data?.error?.message || "Anthropic API error" }, 502);

      const text = (data.content || [])
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("\n")
        .replace(/```json|```/g, "")
        .trim();

      let suggestions;
      try {
        suggestions = JSON.parse(text);
      } catch {
        return json({ error: "Model returned unparseable output", raw: text }, 502);
      }

      return json({ suggestions, usage: data.usage });
    } catch (e) {
      return json({ error: String(e) }, 400);
    }
  },
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, "content-type": "application/json" },
  });
}
